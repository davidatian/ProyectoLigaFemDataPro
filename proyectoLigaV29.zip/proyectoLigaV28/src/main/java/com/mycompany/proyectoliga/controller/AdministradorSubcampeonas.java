package com.mycompany.proyectoliga.controller;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Enciso Suarez
 */
public class AdministradorSubcampeonas {

    public List<Object> obtenerSubCampeonas() {

        List<Object> obtenerSubCampeonas = new ArrayList<>();

        // Se crea lista generiaca para alamacenar diferentes tipos de datos
        obtenerSubCampeonas.add(2023);
        obtenerSubCampeonas.add(" America de Cali");
        obtenerSubCampeonas.add(2022);
        obtenerSubCampeonas.add(" Deportivo Cali");
        obtenerSubCampeonas.add(2021);
        obtenerSubCampeonas.add(" Independiente SantaFe");
        obtenerSubCampeonas.add(2020);
        obtenerSubCampeonas.add(" America de Cali");
        obtenerSubCampeonas.add(2019);
        obtenerSubCampeonas.add(" Independiente Medellin");
        obtenerSubCampeonas.add(2018);
        obtenerSubCampeonas.add(" Atletico Nacional");
        obtenerSubCampeonas.add(2017);
        obtenerSubCampeonas.add(" Atletico Huila");

        return obtenerSubCampeonas;
    }

}
