package com.mycompany.proyectoliga.model;

public class Defensa extends Jugadora {
    public Defensa(String nombre, String apellido, int edad, int dorsal, String nacionalidad) {
        super(nombre, apellido, edad, dorsal, "Defensa", nacionalidad);
    }
}
