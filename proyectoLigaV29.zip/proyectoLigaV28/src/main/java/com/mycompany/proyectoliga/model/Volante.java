package com.mycompany.proyectoliga.model;

public class Volante extends Jugadora {
    public Volante(String nombre, String apellido, int edad, int dorsal, String nacionalidad) {
        super(nombre, apellido, edad, dorsal, "Volante", nacionalidad);
    }
}
