package com.mycompany.proyectoliga.model;

public class Arquera extends Jugadora {

    //Método constructor = new Arquera
    public Arquera(String nombre, String apellido, int edad, int dorsal, String nacionalidad) {
        super(nombre, apellido, edad, dorsal, "Arquera", nacionalidad);
    }
}