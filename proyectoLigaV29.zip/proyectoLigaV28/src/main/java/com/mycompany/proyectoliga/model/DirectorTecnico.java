package com.mycompany.proyectoliga.model;

public class DirectorTecnico extends Jugadora {
    public DirectorTecnico(String nombre, String apellido, int edad, int dorsal, String nacionalidad) {
        super(nombre, apellido, edad, dorsal, "D.T.", nacionalidad);
    }
}
