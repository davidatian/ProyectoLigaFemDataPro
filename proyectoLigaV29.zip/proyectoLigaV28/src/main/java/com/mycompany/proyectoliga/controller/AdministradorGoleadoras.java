package com.mycompany.proyectoliga.controller;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Enciso Suarez
 */
public class AdministradorGoleadoras {

    public List<String> obtenerGoleadoras() {

        List<String> obtenerGoleadoras = new ArrayList<>();

        // Agregar nombres a la lista
        obtenerGoleadoras.add("Catalina Usme - América: 11 goles");
        obtenerGoleadoras.add("Liana Salazar - Santa Fe: 10 goles");
        obtenerGoleadoras.add("María Camila Reyes - Santa Fe: 10 goles");
        obtenerGoleadoras.add("Leidy Cobos - Llaneros: 9 goles");
        obtenerGoleadoras.add("Ana González - Pereira: 8 goles");

        return obtenerGoleadoras;
    }

}
