package com.mycompany.proyectoliga.model;

public class Delantera extends Jugadora {
    public Delantera(String nombre, String apellido, int edad, int dorsal, String nacionalidad) {
        super(nombre, apellido, edad, dorsal, "Delantera", nacionalidad);
    }
}
